declare const styles: {
    passcodeModalContainer: string;
    header: string;
    closeButton: string;
    body: string;
    buttons: string;
};
export default styles;
//# sourceMappingURL=PasscodeModal.module.scss.d.ts.map