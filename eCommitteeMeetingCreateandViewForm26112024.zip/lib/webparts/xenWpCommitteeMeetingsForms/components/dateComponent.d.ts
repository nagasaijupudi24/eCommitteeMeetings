import * as React from "react";
declare const DateTime: React.FC;
export default DateTime;
//# sourceMappingURL=dateComponent.d.ts.map